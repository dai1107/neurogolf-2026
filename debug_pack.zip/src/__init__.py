"""NeuroGolf model generation helpers."""
