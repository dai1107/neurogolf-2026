# 当前进度

## 当前目标

继续提高本地 train solved 数，同时保持 ONNX 合法性、严格验证、可复现性和 submission 安全。正确性优先于模型大小；cost 优化只能作用在已经通过验证的模型上。

## 当前状态

- Local train solved: 44 / 400
- Failed: 356 / 400
- solved 模型 estimated cost 总和: 127396
- Submission: `outputs/submission.zip`
- Submission size: 25818 bytes
- Summary: `outputs/reports/summary.csv`
- Failure taxonomy: `outputs/reports/failure_taxonomy.csv`
- 当前仓库没有 `README.md`

## 最近验证命令

```powershell
python -m pytest
python -m src.build_submission
python -m src.inspect_submission --zip outputs\submission.zip
python -m src.failure_taxonomy
python -m compileall src tests
```

结果：

- `pytest`: 43 passed
- full submission rebuild: 44 solved / 400
- submission inspection: passed, 44 models
- failure taxonomy rows: 356
- rule near-miss rows: 356
- compileall: passed

## 最近成功修改

- 在 `src/onnx_builders.py` 中优化 ONNX mask 存储。
- 将大尺寸 0/1 mask initializer 从 `float32` 改为 `bool`。
- 在图内显式 `Cast` 回 float 后再参与算术。
- 移除 generic spatial remap 中不必要的全 1 `ActiveMask`。
- 将 `ObjectSelectionRule` 工程化为保守静态 bbox builder；当前只命中已 solved 的 `task016`, `task267`。
- 对双射 ColorMap 使用 `Gather(axis=1)` 替代 1x1 Conv；`task016`, `task337` cost 从 500 降到 50。
- 将 LocalNeighborhoodFillRule / LocalNeighborhoodRewriteRule 改为 shape-polymorphic，不再要求所有 train case 共享同一 grid shape。
- 新增 `outputs/reports/rule_near_miss.csv`，用于记录下一轮 near-miss 方向。
- 新增 `HoleFillRule`，使用固定 30 次 Conv flood fill，不使用禁用算子，新增 `task002`, `task251`。
- 新增 dynamic active translation builder；测试通过，但真实 probe 暂无新增。
- 新增保守 `PanelSelectByColorRule`；测试通过，但真实 probe 0 / 400。
- 重新生成所有 candidates、final ONNX、logs、summary、taxonomy 和 submission zip。

## solved 任务

`task001`, `task002`, `task006`, `task016`, `task026`, `task048`, `task053`, `task072`, `task073`, `task081`, `task087`, `task095`, `task116`, `task130`, `task135`, `task140`, `task144`, `task147`, `task164`, `task171`, `task172`, `task210`, `task223`, `task236`, `task251`, `task258`, `task267`, `task272`, `task276`, `task287`, `task291`, `task294`, `task307`, `task309`, `task311`, `task318`, `task326`, `task337`, `task346`, `task352`, `task355`, `task380`, `task385`, `task386`.

## 规则分布

- PanelSeparatorBinaryOpRule: 7
- LocalNeighborhoodFillRule: 6
- MirrorConcatRule: 5
- ColorMapRule: 5
- SubstructureExtractRule: 4
- RotateRule: 3
- CropRule: 2
- ScaleRepeatRule: 2
- HoleFillRule: 2
- SymmetryCompletionRule: 2
- OneStepTranslationRule: 1
- LocalNeighborhoodRewriteRule: 1
- SelfKronMaskRule: 1
- RectangleAndLineRule: 1
- StridedSubsampleRule: 1
- MultiStepTranslationRule: 1

## 新线程优先读取文件

- `AGENTS.md`: 项目规则和安全要求。
- `EXPERIMENT_LOG.md`: 按时间记录的实验交接。
- `PROGRESS.md`: 当前状态和下一步。
- `src/pattern_rules.py`: rule matcher 和确定性 rule 顺序。
- `src/onnx_builders.py`: ONNX 图构造；最近 cost 优化在这里。
- `src/solve_task.py`: candidate 构造、验证和 best-candidate 选择。
- `src/build_submission.py`: 全量 rebuild 和 zip 生成。
- `src/validate_onnx_model.py`: 严格 train 验证。
- `src/cost_estimator.py`: 文件大小、参数量、内存、禁用算子、静态 shape 检查。
- `tests/test_pattern_rules.py`: 主要 rule builder 验证测试。
- `outputs/reports/summary.csv`: 当前 solved/failed 和 cost 的事实来源。
- `outputs/reports/failure_taxonomy.csv`: 当前失败分布。
- `outputs/reports/probe_summary.csv`: probe 线索；正式行动前建议重新生成。
- `outputs/reports/rule_near_miss.csv`: near-miss 报告；当前最大类是 panel_rule_near_miss。

## 当前下一步假设

1. 最高收益来自新增 solved 任务，而不是继续微调当前 44 个模型的 cost。
2. `模型分析及优化策略.md` 的八个方向尚未全部完成；已完成 Local shape-polymorphic、HoleFill、rule_near_miss，部分完成 Translation 和 PanelSelect。
3. 下一步优先做 AutoPeriodExtensionRule probe，目标验证 `task003` 及类似周期扩展任务。
4. 然后补 RectangleAndLineRule 的 bbox_fill / bbox_frame / connect / extend builder。
5. 继续扩展 shrink/crop/object extraction 规则：
   - largest/smallest component crop
   - crop object then normalize to top-left
   - crop by marker color
   - crop interior of frame
6. 对 same-size 失败任务，先 probe 再写 builder：
   - enclosed-region recolor
   - object outline/frame
   - line completion between endpoints
   - ray extension until boundary/object
   - remove isolated/noise components
   - move object toward marker/color/edge

## 当前风险提示

- `ObjectSelectionRule` 现在已有保守 builder，但只支持 train 中 selected bbox 完全静态一致的情况。
- 不要把新的 probe-only rule 加入 `first_version_rules()`，除非 builder 已实现并严格验证。
- 不要把本地 train 验证当作官方榜单分数。
- 不要把 POSSIBLE 或失败候选加入 `submission.zip`。
- 进一步压缩 translation cost 可能需要新 ONNX 结构；使用前必须确认算子合法和 shape 静态。
- `git status --short -- .` 当前显示 `?? ./`，不要假设 Git 能识别本目录内局部改动。

## 停止条件

如果连续三次 rule/builder 尝试都没有新增 validated solved task，就停止继续盲目实现，改为更新 `EXPERIMENT_LOG.md`、`PROGRESS.md` 和失败分析。
