# 实验日志

## 2026-05-30 23:55 - HoleFillRule + dynamic translation probe support

### 目标

继续按 `模型分析及优化策略.md` 推进八个方向中的剩余项。本轮完成：

- 新增 `HoleFillRule`
- 为 `MultiStepTranslationRule` 增加 shape-polymorphic 整图平移支持
- 新增保守 `PanelSelectByColorRule` probe/builder

没有完成全部八个方向；当前仍未达到 50 solved。

### 修改文件

- `src/onnx_builders.py`
- `src/pattern_rules.py`
- `tests/test_pattern_rules.py`
- 重新生成 `outputs/reports/probe_summary.csv`
- 重新生成 `outputs/reports/summary.csv`
- 重新生成 `outputs/reports/failure_taxonomy.csv`
- 重新生成 `outputs/reports/rule_near_miss.csv`
- 重新生成 `outputs/onnx/*.onnx`
- 重新生成 `outputs/logs/*.json`
- 重新生成 `outputs/submission.zip`

### 实现内容

- `HoleFillRule`
  - Python matcher 枚举 `background_color` 和 `fill_color`。
  - 找 background connected components；不接触真实 grid 边界的 background component 视为 hole。
  - ONNX builder 使用固定 30 次 4-neighbor Conv 膨胀做 flood fill，不使用 Loop/Scan/NonZero/Unique。
  - 动态 active mask 用于识别真实 grid 边界，避免把 padding 当背景。
- `MultiStepTranslationRule`
  - 新增 `build_dynamic_fill_translation_model()`。
  - 对不同 train case shape 的 same-size 整图平移，用 input one-hot 动态计算 active cells。
  - padding 区域保持全零，不被填成真实颜色 0。
  - 当前真实 probe 没新增命中，但测试覆盖保留。
- `PanelSelectByColorRule`
  - 保守实现：要求共享 output shape、共享 panel layout、同一 panel index，并且有 selector 证据。
  - selector 当前支持 contains unique color / most non-background / least non-background。
  - 当前真实 probe 0 / 400，未新增 solved。

### 结果

- Local train solved: 44 / 400
- failed: 356 / 400
- 本轮相对 42 solved 新增：
  - `task002` -> HoleFillRule, cost 205, file 12507
  - `task251` -> HoleFillRule, cost 205, file 12507
- 相对 38 solved 的本轮累计新增：
  - `task002`, `task147`, `task251`, `task258`, `task272`, `task352`
- solved 模型 estimated cost 总和: 127396
- `outputs/submission.zip`: 25818 bytes

### 验证命令

已运行：

```powershell
python -m src.probe_rules --data-dir task --report outputs\reports\probe_summary.csv --all-tasks
python -B -m pytest -q
python -m compileall src tests
python -m src.build_submission
python -m src.inspect_submission --zip outputs\submission.zip
python -m src.failure_taxonomy
```

验证结果：

- `pytest`: 43 passed
- full rebuild: 400 tasks processed, 44 solved, 356 failed
- submission inspection: passed, 44 ONNX models
- failure taxonomy rows: 356
- rule_near_miss rows: 356

### 当前未完成项

`模型分析及优化策略.md` 中八个方向没有全部完成。当前完成/部分完成状态：

- shared-shape 过度限制：部分完成，LocalFill/Rewrite 完成；Translation 做了动态整图平移但真实无新增。
- ShapePolymorphicLocalRule：完成，带来 `task147`, `task258`, `task272`, `task352`。
- HoleFillRule：完成，带来 `task002`, `task251`。
- AutoPeriodExtensionRule：未完成。
- ShapePolymorphicTranslationRule：部分完成，测试通过但真实 probe 无新增。
- rule_near_miss.csv：完成。
- RectangleAndLineRule builder 补齐：未完成。
- PanelSelectByColorRule：保守版完成，但真实 probe 0 / 400，需扩展 layout/selector。

### 下一步建议

继续冲 50 solved 时，优先做：

1. `AutoPeriodExtensionRule` Python probe，先确认是否能覆盖 `task003` 及类似任务。
2. `RectangleAndLineRule` 的 bbox_fill / bbox_frame / connect/extend builder 补齐。
3. 扩展 panel 选择，不只限于现有 `_enumerate_panel_layouts_for_grid()` 支持的等宽/等高 panel。

## 2026-05-30 23:30 - Shape-polymorphic local rules

### 目标

根据 `模型分析及优化策略.md`，优先解除局部规则的 shared-shape 过度限制，并生成 `rule_near_miss.csv` 用于下一轮决策。

### 修改文件

- `src/pattern_rules.py`
- `src/onnx_builders.py`
- `src/failure_taxonomy.py`
- `tests/test_pattern_rules.py`
- 重新生成 `outputs/reports/probe_summary.csv`
- 重新生成 `outputs/reports/summary.csv`
- 重新生成 `outputs/reports/failure_taxonomy.csv`
- 新增/重新生成 `outputs/reports/rule_near_miss.csv`
- 重新生成 `outputs/onnx/*.onnx`
- 重新生成 `outputs/logs/*.json`
- 重新生成 `outputs/submission.zip`

### 实现内容

- `LocalNeighborhoodFillRule` 不再要求所有 train case 共享同一 grid shape。
  - 现在只要求每个 case 内部 `input_shape == output_shape`。
  - ONNX builder 原本已经在 padding 全零语义下安全，不会改写 padding。
- `LocalNeighborhoodRewriteRule` 不再要求所有 train case 共享同一 grid shape。
  - 移除了固定 `active_height/active_width` metadata。
  - builder 去掉静态 `ActiveMask`，因为 padding 全 channel 为 0，`target_mask` 为 0，不会触发 rewrite。
- `build_local_neighborhood_fill_model()` 去掉 `ge` 条件下未使用的 `Threshold` initializer，消除 ORT unused initializer 警告并略降 cost。
- `src.failure_taxonomy` 现在同时生成 `outputs/reports/rule_near_miss.csv`。

### 结果

- Local train solved: 42 / 400
- failed: 358 / 400
- 本轮新增 solved:
  - `task147` -> LocalNeighborhoodFillRule, cost 560, file 1314
  - `task258` -> LocalNeighborhoodFillRule, cost 565, file 1476
  - `task272` -> LocalNeighborhoodRewriteRule, cost 560, file 1383
  - `task352` -> LocalNeighborhoodFillRule, cost 565, file 1476
- solved 模型 estimated cost 总和: 126986
- `outputs/submission.zip`: 22262 bytes

### 验证命令

已运行：

```powershell
python -m src.probe_rules --data-dir task --report outputs\reports\probe_summary.csv --all-tasks
python -B -m pytest -q
python -m compileall src tests
python -m src.build_submission
python -m src.inspect_submission --zip outputs\submission.zip
python -m src.failure_taxonomy
```

验证结果：

- `pytest`: 40 passed
- probe:
  - LocalNeighborhoodFillRule: 8 / 400 matched
  - LocalNeighborhoodRewriteRule: 9 / 400 matched
- full rebuild: 400 tasks processed, 42 solved, 358 failed
- submission inspection: passed, 42 ONNX models
- failure taxonomy rows: 358
- rule_near_miss rows: 358

### 当前 rule_near_miss 分布

- panel_rule_near_miss: 168
- blocked_by_shared_shape: 129
- blocked_by_shared_output_shape: 61

### 下一步备注

当前最大 near-miss 类别已经变成 panel 方向。下一轮优先考虑 `PanelSelectByColorRule` 或扩展 `GeneralizedPanelRule`，目标不再只是二元 AND/OR/XOR，而是：

- 输出某个 panel
- 输出含目标颜色的 panel
- 输出去掉 separator 后的某个区域
- 输出多个 panel 中唯一颜色不同的那个
- 输出多个 panel 的局部组合

同时仍有 129 个 `blocked_by_shared_shape`，可继续按策略改造 translation / symmetry / rectangle-line 等规则。

## 2026-05-30 22:40 - ObjectSelection 保守工程化 + ColorMap Gather 优化

### 目标

按 `PROGRESS.md` 的下一步继续优化，但保持保守：先把 `ObjectSelectionRule` 从 probe-only 改成只有静态 bbox 才能生成 ONNX 的正式规则；随后对已 solved 的颜色置换模型做 cost 优化。

### 修改文件

- `src/pattern_rules.py`
- `src/onnx_builders.py`
- `tests/test_pattern_rules.py`
- 重新生成 `outputs/onnx/*.onnx`
- 重新生成 `outputs/candidates/*.onnx`
- 重新生成 `outputs/logs/*.json`
- 重新生成 `outputs/reports/summary.csv`
- 重新生成 `outputs/reports/probe_summary.csv`
- 重新生成 `outputs/reports/failure_taxonomy.csv`
- 重新生成 `outputs/submission.zip`

### 实现内容

- `ObjectSelectionRule` 新增保守 ONNX builder：
  - 新增 `_selected_object_for_case()`，保留选中对象的 bbox 和 crop。
  - 只有所有 train case 选出的 `(top, left, height, width)` 完全一致时才返回 MATCH。
  - build 阶段复用 `build_spatial_remap_model()` 做静态 crop + optional color map。
  - 已加入 `first_version_rules()`。
  - 当前 probe 结果只命中 `task016`, `task267`，都是已 solved，因此没有新增 solved 数。
- `build_color_map_model()` 新增置换优化：
  - 如果完整 color map 是双射，使用 `Gather(axis=1)` 做 channel permutation。
  - 如果不是双射，保持原 1x1 Conv，不改变语义。

### 结果

- Local train solved: 38 / 400
- failed: 362 / 400
- solved 模型 estimated cost 总和: 124736
- `outputs/submission.zip`: 19905 bytes
- `outputs/reports/summary.csv`: 855095 bytes
- `outputs/reports/failure_taxonomy.csv`: 39852 bytes

ColorMap 优化结果：

- `task016` ColorMapRule: cost 500 -> 50, file 599 -> 238
- `task337` ColorMapRule: cost 500 -> 50, file 599 -> 238
- `task267`, `task276`, `task309` 是非双射或存在 channel collision，继续使用 Conv，cost 保持 500。

### 验证命令

已运行：

```powershell
python -m src.probe_rules --data-dir task --report outputs\reports\probe_summary.csv --all-tasks
python -m pytest
python -m src.build_submission
python -m src.inspect_submission --zip outputs\submission.zip
python -m src.failure_taxonomy
python -m compileall src tests
```

验证结果：

- `probe_rules`: ObjectSelectionRule 2 / 400 matched: `task016 task267`
- `pytest`: 38 passed
- full rebuild: 400 tasks processed, 38 solved, 362 failed
- submission inspection: passed, 38 ONNX models
- failure taxonomy rows: 362

### 下一步备注

保守静态 ObjectSelection 不足以解决 `task031`, `task036`, `task259`, `task300`，因为这些任务需要动态对象选择或动态 top-left normalization。下一步如果继续攻这些任务，应先做新的 probe，明确是否能用合法 ONNX 静态图实现动态 bbox/translation，避免直接写高成本或不合规模型。

## 2026-05-30 22:10 - Bool mask cost 优化

### 目标

在不扩大规则匹配面、不引入未验证模型的前提下，降低当前已解决 ONNX 模型的 estimated cost 和文件体积。

正确性仍然是硬门槛：最终模型必须通过 ONNX checker、禁用算子检查、静态 shape 检查、严格 train 验证、文件大小检查和 cost 统计。

### 当前背景

- 本地 train solved: 38 / 400
- failed: 362 / 400
- `outputs/submission.zip` 已生成，并通过 `inspect_submission`
- 当前仓库没有 `README.md`。新线程接手时优先读 `AGENTS.md`、`PROGRESS.md`、本文档、`outputs/reports/summary.csv` 和核心源码。
- `git status --short -- .` 当前显示 `?? ./`，说明这个目录整体在可见 Git 基线里是未跟踪状态。不要依赖 tracked diff 来恢复进度。

### 修改文件

- `src/onnx_builders.py`
- 重新生成 `outputs/onnx/*.onnx`
- 重新生成 `outputs/candidates/*.onnx`
- 重新生成 `outputs/logs/*.json`
- 重新生成 `outputs/reports/summary.csv`
- 重新生成 `outputs/reports/failure_taxonomy.csv`
- 重新生成 `outputs/submission.zip`

### 实现内容

- 新增 `_bool_mask()` 和 `_cast_to_float()` helper。
- 将只表示 0/1 的大尺寸 mask initializer 从 `float32` 改成 `bool`。
- 在 ONNX 图内用显式 `Cast(..., to=FLOAT)` 转回 float，再参与 `Mul` / `Sub`。
- 对全 1 的 `ActiveMask` 直接省略；不需要 mask 时输出改成 `Identity`。
- 覆盖的 builder：
  - spatial remap
  - one-step translation
  - zero-fill translation
  - single-color translation
  - panel binary op
  - generalized panel op
  - periodic extension color map
  - symmetry completion
  - self-kron mask
  - local neighborhood rewrite
  - rotate

### 结果

- Local train solved: 38 / 400
- solved 模型 estimated cost 总和: 125636
- `outputs/submission.zip`: 19920 bytes
- `outputs/reports/summary.csv`: 816091 bytes
- `outputs/reports/failure_taxonomy.csv`: 39852 bytes

全量重建后的主要 cost 改善：

- `task073` MultiStepTranslationRule: 13718 -> 8318
- `task053` OneStepTranslationRule: 9350 -> 3950
- 通用 spatial remap 类任务：常见 9063 -> 4563
- panel 类任务：约 5250 -> 2550 / 2555
- `task001` SelfKronMaskRule: 5200 -> 2500
- `task287` / `task385` SymmetryCompletionRule: 4950 -> 2250

### 验证命令

已运行：

```powershell
python -m pytest
python -m src.build_submission
python -m src.inspect_submission --zip outputs\submission.zip
python -m src.failure_taxonomy
python -m compileall src tests
```

验证结果：

- `pytest`: 37 passed
- 全量 rebuild: 400 tasks processed, 38 solved, 362 failed
- submission inspection: passed, 38 ONNX models
- failure taxonomy rows: 362
- compileall: passed

### solved 规则分布

- PanelSeparatorBinaryOpRule: 7
- MirrorConcatRule: 5
- ColorMapRule: 5
- SubstructureExtractRule: 4
- RotateRule: 3
- LocalNeighborhoodFillRule: 3
- CropRule: 2
- ScaleRepeatRule: 2
- SymmetryCompletionRule: 2
- OneStepTranslationRule: 1
- SelfKronMaskRule: 1
- RectangleAndLineRule: 1
- StridedSubsampleRule: 1
- MultiStepTranslationRule: 1

### 当前 solved 任务列表

`task001`, `task006`, `task016`, `task026`, `task048`, `task053`, `task072`, `task073`, `task081`, `task087`, `task095`, `task116`, `task130`, `task135`, `task140`, `task144`, `task164`, `task171`, `task172`, `task210`, `task223`, `task236`, `task267`, `task276`, `task287`, `task291`, `task294`, `task307`, `task309`, `task311`, `task318`, `task326`, `task337`, `task346`, `task355`, `task380`, `task385`, `task386`.

### 当前仍然 cost 较高的 solved 模型

- `task073` MultiStepTranslationRule: cost 8318, file 6966
- `task048` / `task291` / `task346` / `task355` SubstructureExtractRule: cost 6863, file 5569
- `task326` CropRule: cost 6363, file 5058
- 多个 spatial remap 模型：cost 4563, file 4053

不要在没有严格验证的情况下继续压这些模型。进一步压缩 translation 可能需要新的 ONNX 结构，例如 `Pad` 或更小中间张量，应作为单独实验，并先确认算子合法性和静态 shape。

### 失败任务分类

来自 `outputs/reports/failure_taxonomy.csv`：

- variable_shapes: 194
- same_size: 122
- shrinks_or_crop: 34
- integer_scale_or_tile: 11
- expands_non_integer: 1

### probe 备注

当前 `outputs/reports/probe_summary.csv` 不是 bool mask 优化后重新生成的，但仍可作为方向参考：

- ObjectSelectionRule 命中 9 个任务：`task016 task031 task036 task259 task267 task276 task300 task309 task337`
- 其中已 solved：`task016`, `task267`, `task276`, `task309`, `task337`
- 如果实现保守 ONNX builder，潜在未 solved 目标：`task031`, `task036`, `task259`, `task300`

### 下一步假设

1. 优先实现保守版 `ObjectSelectionRule` ONNX builder。只允许 selected bbox 坐标和输出 shape 在 train 样例中静态一致的情况进入 MATCH。
2. 在继续 same-size 局部规则前，优先扩展 shrink/crop/object normalization 类规则。
3. 继续使用 probe-first 流程：先写 Python matcher，跑 `probe_rules`，确认 MATCH 数量后再写 ONNX builder。
4. 新候选必须通过所有验证和约束检查后，才能进入 `submission.zip`。
