from __future__ import annotations

from src.pattern_rules import (
    ColorMapRule,
    CropRule,
    GeneralizedPanelRule,
    HoleFillRule,
    IdentityRule,
    LocalNeighborhoodFillRule,
    LocalNeighborhoodRewriteRule,
    MirrorConcatRule,
    MultiStepTranslationRule,
    ObjectSelectionRule,
    PanelSelectByColorRule,
    OneStepTranslationRule,
    PanelSeparatorBinaryOpRule,
    PeriodicExtensionColorMapRule,
    RectangleAndLineRule,
    ScaleRepeatRule,
    SelfKronMaskRule,
    StridedSubsampleRule,
    SubstructureExtractRule,
    SymmetryCompletionRule,
    TileFromBBoxRepeatRule,
)
from src.validate_onnx_model import validate_task


def _assert_rule_builds_and_validates(rule, task, tmp_path) -> None:
    result = rule.match(task)
    assert result.matched is True
    model_path = tmp_path / f"{rule.name}.onnx"
    rule.build("task999", task, str(model_path), result.metadata)
    validation = validate_task(str(model_path), task)
    assert validation["passed"] is True


def test_identity_rule_matches_identity_task() -> None:
    task = {"train": [{"input": [[1, 0], [2, 3]], "output": [[1, 0], [2, 3]]}]}

    result = IdentityRule().match(task)

    assert result.matched is True
    assert result.confidence == "MATCH"


def test_identity_rule_rejects_non_identity_task() -> None:
    task = {"train": [{"input": [[1]], "output": [[2]]}]}

    result = IdentityRule().match(task)

    assert result.matched is False


def test_color_map_rule_infers_global_mapping() -> None:
    task = {
        "train": [
            {"input": [[1, 0], [1, 0]], "output": [[2, 0], [2, 0]]},
            {"input": [[3, 1]], "output": [[4, 2]]},
        ]
    }

    result = ColorMapRule().match(task)

    assert result.matched is True
    assert result.metadata["color_map"] == {1: 2, 0: 0, 3: 4}


def test_color_map_rule_rejects_inconsistent_mapping() -> None:
    task = {"train": [{"input": [[1, 1]], "output": [[2, 3]]}]}

    result = ColorMapRule().match(task)

    assert result.matched is False
    assert "inconsistent mapping" in result.reason


def test_one_step_translation_rule_detects_shared_shift() -> None:
    task = {
        "train": [
            {
                "input": [[1, 2], [3, 4]],
                "output": [[0, 1], [0, 3]],
            },
            {
                "input": [[5, 6], [7, 8]],
                "output": [[0, 5], [0, 7]],
            },
        ]
    }

    result = OneStepTranslationRule().match(task)

    assert result.matched is True
    assert result.metadata["dy"] == 0
    assert result.metadata["dx"] == 1


def test_one_step_translation_rule_rejects_different_shifts() -> None:
    task = {
        "train": [
            {
                "input": [[1, 2], [3, 4]],
                "output": [[0, 1], [0, 3]],
            },
            {
                "input": [[5, 6], [7, 8]],
                "output": [[0, 0], [5, 6]],
            },
        ]
    }

    result = OneStepTranslationRule().match(task)

    assert result.matched is False


def test_crop_rule_detects_fixed_crop() -> None:
    task = {
        "train": [
            {"input": [[1, 2, 3], [4, 5, 6]], "output": [[2, 3], [5, 6]]},
            {"input": [[7, 8, 9], [1, 2, 3]], "output": [[8, 9], [2, 3]]},
        ]
    }

    result = CropRule().match(task)

    assert result.matched is True
    assert result.metadata["top"] == 0
    assert result.metadata["left"] == 1


def test_scale_repeat_rule_detects_nearest_repeat() -> None:
    task = {
        "train": [
            {
                "input": [[1, 2], [3, 4]],
                "output": [
                    [1, 1, 2, 2],
                    [1, 1, 2, 2],
                    [3, 3, 4, 4],
                    [3, 3, 4, 4],
                ],
            }
        ]
    }

    result = ScaleRepeatRule().match(task)

    assert result.matched is True
    assert result.metadata["scale_y"] == 2
    assert result.metadata["scale_x"] == 2


def test_strided_subsample_rule_detects_fixed_stride() -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 9, 2, 9],
                    [9, 9, 9, 9],
                    [3, 9, 4, 9],
                    [9, 9, 9, 9],
                ],
                "output": [[1, 2], [3, 4]],
            }
        ]
    }

    result = StridedSubsampleRule().match(task)

    assert result.matched is True
    assert result.metadata["stride_y"] == 2
    assert result.metadata["stride_x"] == 2


def test_mirror_concat_rule_detects_horizontal_append() -> None:
    task = {"train": [{"input": [[1, 2], [3, 4]], "output": [[1, 2, 2, 1], [3, 4, 4, 3]]}]}

    result = MirrorConcatRule().match(task)

    assert result.matched is True
    assert result.metadata["mode"] == "h_input_mirror"


def test_self_kron_mask_rule_detects_template_expansion() -> None:
    task = {
        "train": [
            {
                "input": [[1, 0], [2, 3]],
                "output": [
                    [1, 0, 0, 0],
                    [2, 3, 0, 0],
                    [1, 0, 1, 0],
                    [2, 3, 2, 3],
                ],
            }
        ]
    }

    result = SelfKronMaskRule().match(task)

    assert result.matched is True


def test_panel_separator_binary_op_rule_builds_valid_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 0, 9, 0, 1],
                    [1, 0, 9, 1, 0],
                ],
                "output": [
                    [0, 0],
                    [2, 0],
                ],
            }
        ]
    }

    rule = PanelSeparatorBinaryOpRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["operation"] == "AND"
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_generalized_panel_rule_supports_multi_col_separator(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 0, 9, 9, 0, 1],
                    [1, 0, 9, 9, 1, 0],
                ],
                "output": [
                    [0, 0],
                    [2, 0],
                ],
            }
        ]
    }

    rule = GeneralizedPanelRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["operation"] == "AND"
    assert result.metadata["separator_width"] == 2
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_generalized_panel_rule_supports_2x2_majority(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 0, 9, 1, 0],
                    [0, 0, 9, 1, 1],
                    [9, 9, 9, 9, 9],
                    [1, 1, 9, 0, 0],
                    [0, 1, 9, 0, 1],
                ],
                "output": [
                    [2, 0],
                    [0, 2],
                ],
            }
        ]
    }

    rule = GeneralizedPanelRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["layout"] == "grid_2x2"
    assert result.metadata["operation"] == "MAJORITY"
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_panel_select_by_color_rule_builds_static_panel_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 0, 9, 0, 2],
                    [1, 1, 9, 2, 2],
                ],
                "output": [
                    [0, 2],
                    [2, 2],
                ],
            },
            {
                "input": [
                    [3, 0, 9, 0, 2],
                    [3, 3, 9, 2, 2],
                ],
                "output": [
                    [0, 2],
                    [2, 2],
                ],
            },
        ]
    }

    rule = PanelSelectByColorRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["panel_index"] == 1
    assert result.metadata["selector"] == "contains_unique_color_2"
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_periodic_extension_color_map_rule_builds_valid_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [[1, 2], [3, 4]],
                "output": [
                    [1, 2, 1, 2, 1],
                    [3, 4, 3, 4, 3],
                    [1, 2, 1, 2, 1],
                ],
            }
        ]
    }

    rule = PeriodicExtensionColorMapRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["period_y"] == 2
    assert result.metadata["period_x"] == 2
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_local_neighborhood_fill_rule_builds_valid_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 1, 0],
                    [0, 0, 0],
                    [0, 1, 0],
                ],
                "output": [
                    [0, 1, 0],
                    [0, 2, 0],
                    [0, 1, 0],
                ],
            }
        ]
    }

    rule = LocalNeighborhoodFillRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["background_color"] == 0
    assert result.metadata["fill_color"] == 2
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_hole_fill_rule_builds_valid_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 1, 1, 1],
                    [1, 0, 0, 1],
                    [1, 0, 1, 1],
                    [1, 1, 1, 1],
                ],
                "output": [
                    [1, 1, 1, 1],
                    [1, 2, 2, 1],
                    [1, 2, 1, 1],
                    [1, 1, 1, 1],
                ],
            },
            {
                "input": [
                    [1, 1, 1, 1, 1],
                    [1, 0, 0, 0, 1],
                    [1, 0, 1, 0, 1],
                    [1, 1, 1, 1, 1],
                ],
                "output": [
                    [1, 1, 1, 1, 1],
                    [1, 2, 2, 2, 1],
                    [1, 2, 1, 2, 1],
                    [1, 1, 1, 1, 1],
                ],
            },
        ]
    }

    rule = HoleFillRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["background_color"] == 0
    assert result.metadata["fill_color"] == 2
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_local_neighborhood_fill_rule_supports_variable_case_shapes(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 1, 0],
                    [0, 0, 0],
                    [0, 1, 0],
                ],
                "output": [
                    [0, 1, 0],
                    [0, 2, 0],
                    [0, 1, 0],
                ],
            },
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 1, 0, 0],
                    [0, 0, 0, 0],
                    [0, 1, 0, 0],
                ],
                "output": [
                    [0, 0, 0, 0],
                    [0, 1, 0, 0],
                    [0, 2, 0, 0],
                    [0, 1, 0, 0],
                ],
            },
        ]
    }

    rule = LocalNeighborhoodFillRule()
    result = rule.match(task)

    assert result.matched is True
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_substructure_extract_rule_supports_color_map(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 1, 2, 0],
                    [0, 3, 4, 0],
                ],
                "output": [[5, 6], [7, 8]],
            }
        ]
    }

    rule = SubstructureExtractRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["top"] == 1
    assert result.metadata["left"] == 1
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_substructure_extract_rule_supports_color_bbox(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 5, 5, 0],
                    [0, 5, 0, 0],
                ],
                "output": [[5, 5], [5, 0]],
            }
        ]
    }

    rule = SubstructureExtractRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["kind"] == "color_bbox"
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_tile_from_bbox_repeat_rule_builds_valid_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 1, 2, 0],
                    [0, 3, 4, 0],
                ],
                "output": [
                    [1, 2, 1, 2, 1],
                    [3, 4, 3, 4, 3],
                    [1, 2, 1, 2, 1],
                ],
            }
        ]
    }

    rule = TileFromBBoxRepeatRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["tile_height"] == 2
    assert result.metadata["tile_width"] == 2
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_tile_from_bbox_repeat_rule_supports_truncated_last_tile(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 1, 2, 3],
                    [0, 4, 5, 6],
                ],
                "output": [
                    [1, 2, 3, 1],
                    [4, 5, 6, 4],
                    [1, 2, 3, 1],
                ],
            }
        ]
    }

    rule = TileFromBBoxRepeatRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["tile_height"] == 2
    assert result.metadata["tile_width"] == 3
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_multi_step_translation_rule_builds_valid_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 2, 3, 4],
                    [5, 6, 7, 8],
                ],
                "output": [
                    [0, 0, 1, 2],
                    [0, 0, 5, 6],
                ],
            }
        ]
    }

    rule = MultiStepTranslationRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["dy"] == 0
    assert result.metadata["dx"] == 2
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_multi_step_translation_rule_supports_single_color_object(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 2, 0, 0],
                    [0, 2, 0, 0],
                    [3, 0, 0, 0],
                ],
                "output": [
                    [0, 0, 0, 2],
                    [0, 0, 0, 2],
                    [3, 0, 0, 0],
                ],
            }
        ]
    }

    rule = MultiStepTranslationRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["mode"] == "single_color"
    assert result.metadata["dx"] == 2
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_multi_step_translation_rule_supports_variable_case_shapes(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 2, 3],
                    [4, 5, 6],
                ],
                "output": [
                    [0, 0, 1],
                    [0, 0, 4],
                ],
            },
            {
                "input": [
                    [1, 2, 3, 4],
                    [5, 6, 7, 8],
                    [9, 1, 2, 3],
                ],
                "output": [
                    [0, 0, 1, 2],
                    [0, 0, 5, 6],
                    [0, 0, 9, 1],
                ],
            },
        ]
    }

    rule = MultiStepTranslationRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["dynamic_active"] is True
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_symmetry_completion_rule_builds_valid_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 0, 0],
                    [2, 0, 0],
                    [3, 0, 0],
                ],
                "output": [
                    [1, 0, 1],
                    [2, 0, 2],
                    [3, 0, 3],
                ],
            }
        ]
    }

    rule = SymmetryCompletionRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["mode"] == "horizontal"
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_local_neighborhood_fill_rule_supports_5x5_kernel(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [1, 0, 0, 0, 1],
                    [0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0],
                    [0, 0, 0, 0, 0],
                    [1, 0, 0, 0, 1],
                ],
                "output": [
                    [1, 0, 0, 0, 1],
                    [0, 0, 0, 0, 0],
                    [0, 0, 2, 0, 0],
                    [0, 0, 0, 0, 0],
                    [1, 0, 0, 0, 1],
                ],
            }
        ]
    }

    rule = LocalNeighborhoodFillRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["offset_name"] in {"all24", "diagonal8"}
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_local_neighborhood_rewrite_rule_deletes_isolated_cell(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0],
                    [0, 1, 0],
                    [0, 0, 0],
                ],
                "output": [
                    [0, 0, 0],
                    [0, 0, 0],
                    [0, 0, 0],
                ],
            }
        ]
    }

    rule = LocalNeighborhoodRewriteRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["target_color"] == 1
    assert result.metadata["replacement_color"] == 0
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_local_neighborhood_rewrite_rule_supports_variable_case_shapes(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0],
                    [0, 1, 0],
                    [0, 0, 0],
                ],
                "output": [
                    [0, 0, 0],
                    [0, 0, 0],
                    [0, 0, 0],
                ],
            },
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [0, 0, 1, 0],
                    [0, 0, 0, 0],
                ],
                "output": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                ],
            },
        ]
    }

    rule = LocalNeighborhoodRewriteRule()
    result = rule.match(task)

    assert result.matched is True
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_rectangle_and_line_rule_probe_detects_bbox_frame() -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 1, 1, 0],
                    [0, 1, 1, 0],
                    [0, 0, 0, 0],
                ],
                "output": [
                    [0, 0, 0, 0],
                    [0, 2, 2, 0],
                    [0, 2, 2, 0],
                    [0, 0, 0, 0],
                ],
            }
        ]
    }

    result = RectangleAndLineRule().match(task)

    assert result.matched is True
    assert result.metadata["mode"] == "bbox_fill"


def test_rectangle_and_line_rule_builds_active_frame_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                    [0, 0, 0, 0],
                ],
                "output": [
                    [8, 8, 8, 8],
                    [8, 0, 0, 8],
                    [8, 8, 8, 8],
                ],
            },
            {
                "input": [
                    [0, 0, 0],
                    [0, 0, 0],
                    [0, 0, 0],
                    [0, 0, 0],
                ],
                "output": [
                    [8, 8, 8],
                    [8, 0, 8],
                    [8, 0, 8],
                    [8, 8, 8],
                ],
            },
        ]
    }

    rule = RectangleAndLineRule()
    result = rule.match(task)

    assert result.matched is True
    assert result.metadata["mode"] == "active_frame"
    _assert_rule_builds_and_validates(rule, task, tmp_path)


def test_object_selection_rule_probe_detects_largest_component() -> None:
    task = {
        "train": [
            {
                "input": [
                    [2, 0, 0, 1],
                    [2, 2, 0, 2],
                    [0, 0, 0, 2],
                ],
                "output": [
                    [2, 0],
                    [2, 2],
                ],
            },
            {
                "input": [
                    [2, 0, 1, 0],
                    [2, 2, 0, 2],
                    [0, 0, 0, 2],
                ],
                "output": [
                    [2, 0],
                    [2, 2],
                ],
            },
        ]
    }

    result = ObjectSelectionRule().match(task)

    assert result.matched is True
    assert result.metadata["kind"] == "color_component"
    assert result.metadata["selector"] == "largest_area"
    assert result.metadata["top"] == 0
    assert result.metadata["left"] == 0


def test_object_selection_rule_builds_static_component_model(tmp_path) -> None:
    task = {
        "train": [
            {
                "input": [
                    [2, 0, 0, 1],
                    [2, 2, 0, 2],
                    [0, 0, 0, 2],
                ],
                "output": [
                    [2, 0],
                    [2, 2],
                ],
            },
            {
                "input": [
                    [2, 0, 1, 0],
                    [2, 2, 0, 2],
                    [0, 0, 0, 2],
                ],
                "output": [
                    [2, 0],
                    [2, 2],
                ],
            },
        ]
    }

    _assert_rule_builds_and_validates(ObjectSelectionRule(), task, tmp_path)
